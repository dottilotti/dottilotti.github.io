<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>DottiLotti</title>
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js" type="text/javascript"></script>
<script>
/*$(document).ready(function(){


				$(".thumb1").hide();
				$(".thumb2").hide();
				$(".thumb").show();
				$('.thumb').click(function(){
			    $(".thumb1").slideToggle();
				//$(".thumb2").hide();
				});
				$('.thumb1').click(function(){
			    $(".thumb2").slideToggle();
				});
})
*/
</script>
</head>

<body>

  <div class="header_bg">
    <div class="container">
      <div class="row">
        <div class="header_padding">
        <div class="side_strip">
                <div class="set_padding">
          <div class="head_bg"></div>
           <div class="head_bg-left"></div>
           <div class="head_bg-right"></div>
           <div class="head_bg-bottom"></div>
          <div class="header">
<nav class="navbar navbar-default">
            <div class="container-fluid"> 
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                <a class="navbar-brand" href="#"><img src="images/dottilotti_logo.png" /></a> </div>
              
              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right header_menu">
                  <li ><a href="index.html">Home</a></li>
                  <li class="active dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Karten  <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li><a href="product.html">Karten</a></li>
                      <li><a href="mandala_karten.html">Mandala Karten</a></li>
                    </ul>
                  </li>
                  <li><a href="versand.html">Versand</a></li>
                  <li><a href="kontakt.html" class="last">Kontakt</a></li>
                </ul>
              </div>
              <!-- /.navbar-collapse --> 
            </div>
            <!-- /.container-fluid --> 
            
          </nav>
          <div class="row">

            <div class="col-lg-4 col-md-4 col-xs-6 list_slider ">
                   <a class="thumbnail" href="detail_mandala.html">   <img class="img-responsive" src="images/mandala1.jpg" alt=""></a>
                  <a  id="products_bg" class="thumb home_sect" href="#"><img class="img-responsive" src="images/arrow.png" alt="" style="width: 30px;height: 30px;">
              </a>
            </div>
            <div class="col-lg-4 col-md-4 col-xs-6 list_slider ">
                   <a id="products_bg1" class="thumbnail thumb1" href="detail_mandala2.html">   <img class="img-responsive" src="images/mandala2.jpg" alt=""></a>
                  <a  id="products_bg1" class="thumb1 home_sect" href="#"><img class="img-responsive" src="images/arrow.png" alt="" style="width: 30px;height: 30px;">
              </a>
            </div>
            <div class="col-lg-4 col-md-4 col-xs-6 thumb2" id="products_bg2">
                <a class="thumbnail" href="detail_mandala3.html">
                    <img class="img-responsive" src="images/Mandala3.jpg" alt="">
                </a>
            </div>
            <div class="col-lg-4 col-md-4 col-xs-6 thumb2" id="products_bg2">
                <a class="thumbnail" href="detail_mandala4.html">
                    <img class="img-responsive" src="images/Mandala4.jpg" alt="">
                </a>
            </div>
            <div class="col-lg-4 col-md-4 col-xs-6 thumb2" id="products_bg2">
                <a class="thumbnail" href="detail_mandala5.html">
                    <img class="img-responsive" src="images/Mandala5.jpg" alt="">
                </a>
            </div>
            <div class="col-lg-4 col-md-4 col-xs-6 thumb2" id="products_bg2">
                <a class="thumbnail" href="detail_mandala6.html">
                    <img class="img-responsive" src="images/Mandala6.jpg" alt="">
                </a>
            </div>
            <div class="col-lg-4 col-md-4 col-xs-6 thumb2" id="products_bg2">
                <a class="thumbnail" href="detail_mandala7.html">
                    <img class="img-responsive" src="images/Mandala7.jpg" alt="">
                </a>
            </div>
            <div class="col-lg-4 col-md-4 col-xs-6 thumb2" id="products_bg2">
                <a class="thumbnail" href="detail_mandala8.html">
                    <img class="img-responsive" src="images/Mandala8.jpg" alt="">
                </a>
            </div>
            <div class="col-lg-4 col-md-4 col-xs-6 thumb2" id="products_bg2">
                <a class="thumbnail" href="detail_mandala9.html">
                    <img class="img-responsive" src="images/Mandala9.jpg" alt="">
                </a>
            </div>
            <div class="col-lg-4 col-md-4 col-xs-6 thumb2" id="products_bg2">
                <a class="thumbnail" href="detail_mandala10.html">
                    <img class="img-responsive" src="images/Banner_img1.jpg" alt="">
                </a>
            </div>
        </div>
        </div>
       </div>
    </div>
    
    <footer>
    <div class="footer">
    <p align="center"><i>Copyright@2016 dottilotti - All Rights Reserved</i></p>
    </div>
    </footer>
    </div>
  </div>
</div>
</div>


</body></html>